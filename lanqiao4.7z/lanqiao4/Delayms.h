#ifndef __DELAYMS_H__
#define __DELAYMS_H__

void Delayms(unsigned int xms);

#endif
